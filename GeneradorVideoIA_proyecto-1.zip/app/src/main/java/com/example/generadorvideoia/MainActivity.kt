package com.example.generadorvideoia

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("videoia", MODE_PRIVATE) }
    private var selectedPlan = "Pro"
    private lateinit var creditsText: TextView
    private lateinit var planText: TextView

    private fun creditsForPlan() = when (selectedPlan) { "Ultra" -> 8; "Turbo" -> 15; else -> 3 }
    private fun refreshCredits() {
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_reset", 0L)
        if (last == 0L || now - last >= 24L * 60 * 60 * 1000) {
            prefs.edit().putInt("credits", 3).putLong("last_reset", now).apply()
        }
        creditsText.text = "Créditos disponibles: ${prefs.getInt("credits", 3)}"
    }
    private fun txt(s: String, size: Float = 16f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.rgb(30,30,40)); setPadding(0,10,0,10)
    }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply { text=s; setOnClickListener { action() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24,28,24,28); setBackgroundColor(Color.rgb(248,249,255))
        }
        val scroll = ScrollView(this); scroll.addView(page)
        page.addView(txt("GeneradorVideoIA", 28f).apply { setTypeface(null, Typeface.BOLD); gravity=Gravity.CENTER })
        page.addView(txt("Crea ideas para videos con inteligencia artificial"))
        creditsText = txt(""); page.addView(creditsText); refreshCredits()
        page.addView(txt("Elegí tu plan",20f).apply { setTypeface(null,Typeface.BOLD) })
        planText = txt("Plan seleccionado: Pro"); page.addView(planText)
        page.addView(btn("Pro — 3 créditos diarios") { choose("Pro") })
        page.addView(btn("Ultra — 8 créditos diarios") { choose("Ultra") })
        page.addView(btn("Turbo — 15 créditos diarios") { choose("Turbo") })
        page.addView(txt("Describe tu video",20f).apply { setTypeface(null,Typeface.BOLD) })
        val prompt = EditText(this).apply { hint="Ej.: Un héroe con capucha pelea contra monstruos..."; minLines=4; gravity=Gravity.TOP; setPadding(12,12,12,12); setBackgroundColor(Color.WHITE) }
        page.addView(prompt)
        page.addView(btn("Preparar video") {
            val count = prefs.getInt("credits",3)
            when {
                prompt.text.toString().trim().isEmpty() -> Toast.makeText(this,"Escribí una descripción primero.",Toast.LENGTH_LONG).show()
                count <= 0 -> Toast.makeText(this,"No te quedan créditos. Se renuevan cada 24 horas.",Toast.LENGTH_LONG).show()
                else -> Toast.makeText(this,"Prototipo listo. Para generar videos reales hay que conectar un servicio de IA y un servidor seguro.",Toast.LENGTH_LONG).show()
            }
        })
        page.addView(txt("Importante",18f).apply { setTypeface(null,Typeface.BOLD) })
        page.addView(txt("Esta es una base instalable. Todavía no genera videos reales ni procesa pagos. Los planes y créditos son una demostración local. Para activar videos, voces y sonido hay que integrar una API de IA mediante un servidor seguro."))
        setContentView(scroll)
    }
    private fun choose(plan: String) {
        selectedPlan=plan; planText.text="Plan seleccionado: $plan"
        Toast.makeText(this,"Seleccionaste $plan",Toast.LENGTH_SHORT).show()
    }
}
