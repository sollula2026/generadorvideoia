# GeneradorVideoIA

Proyecto Android inicial en Kotlin para compilar una APK de prueba.

Incluye pantalla inicial, selector visual Pro/Ultra/Turbo, aviso de créditos diarios y workflow de GitHub Actions para compilar la APK.

**Importante:** esta versión es un prototipo instalable; todavía no genera videos reales, voces ni sonido, y no procesa pagos. Para activar generación real se necesita integrar un proveedor de video IA y un backend seguro. Las claves de API nunca deben guardarse dentro de la APK. Los créditos actuales son demostrativos y locales, no un control seguro de consumo.

## Cómo compilar desde GitHub
1. Descomprimí el ZIP.
2. Subí todo el contenido al repositorio `generadorvideoia`, conservando las carpetas `app` y `.github`.
3. Confirmá el commit en `main`.
4. Abrí **Actions** y elegí **Construir APK Android**.
5. Si no comenzó sola, tocá **Run workflow**.
6. Cuando termine, descargá el artefacto **GeneradorVideoIA-debug**. Ahí está `app-debug.apk`.

La compilación usa Java 17 y Gradle 8.9 en GitHub Actions.
